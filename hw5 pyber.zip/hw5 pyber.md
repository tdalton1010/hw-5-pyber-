

```python
# Dependencies
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
```


```python
city_csv = pd.read_csv("raw_data/city_data.csv")
ride_csv = pd.read_csv("raw_data/ride_data.csv")

city_data_clean = pd.DataFrame({'type': city_csv.groupby('city').first()['type'],
                                'driver_count': city_csv.groupby('city').sum()['driver_count']}).reset_index()


pyber_df = pd.merge(ride_csv, city_data_clean, on="city", how="outer" )

pyber_df_city = pyber_df.groupby("city")
pyber_df_city.head(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
      <td>46</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>27</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
      <td>35</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
      <td>55</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>68</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
      <td>68</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>94</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>120</th>
      <td>New Jeffrey</td>
      <td>2016-02-22 18:36:25</td>
      <td>36.01</td>
      <td>9757888452346</td>
      <td>58</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>145</th>
      <td>Port Johnstad</td>
      <td>2016-06-07 02:39:58</td>
      <td>17.15</td>
      <td>4352278259335</td>
      <td>22</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>179</th>
      <td>Jacobfort</td>
      <td>2016-09-20 20:58:37</td>
      <td>22.98</td>
      <td>1500221409082</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>210</th>
      <td>Travisville</td>
      <td>2016-01-15 17:32:02</td>
      <td>27.39</td>
      <td>850152768361</td>
      <td>37</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>233</th>
      <td>Sandymouth</td>
      <td>2016-11-16 07:27:00</td>
      <td>21.61</td>
      <td>2389035050524</td>
      <td>11</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>260</th>
      <td>New Andreamouth</td>
      <td>2016-04-11 07:20:48</td>
      <td>7.72</td>
      <td>9992929847990</td>
      <td>42</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>288</th>
      <td>New Christine</td>
      <td>2016-09-13 15:06:42</td>
      <td>24.89</td>
      <td>7918411468537</td>
      <td>22</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>310</th>
      <td>Stewartview</td>
      <td>2016-03-29 05:15:56</td>
      <td>23.88</td>
      <td>6778235889588</td>
      <td>49</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>340</th>
      <td>Rodriguezburgh</td>
      <td>2016-09-05 05:20:39</td>
      <td>4.54</td>
      <td>9650770953139</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>363</th>
      <td>West Sydneyhaven</td>
      <td>2016-08-02 21:18:44</td>
      <td>12.87</td>
      <td>7994760397230</td>
      <td>70</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>381</th>
      <td>Swansonbury</td>
      <td>2016-07-11 18:42:11</td>
      <td>39.30</td>
      <td>744481862626</td>
      <td>64</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>415</th>
      <td>Lisatown</td>
      <td>2016-07-05 18:09:14</td>
      <td>5.82</td>
      <td>6370359473201</td>
      <td>47</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>438</th>
      <td>East Erin</td>
      <td>2016-11-03 01:03:05</td>
      <td>7.51</td>
      <td>4744239092530</td>
      <td>43</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>466</th>
      <td>Port Martinberg</td>
      <td>2016-01-06 17:11:30</td>
      <td>8.66</td>
      <td>7298562820881</td>
      <td>44</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>487</th>
      <td>Edwardsbury</td>
      <td>2016-02-27 03:55:54</td>
      <td>20.17</td>
      <td>8514523868075</td>
      <td>11</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>514</th>
      <td>Pamelahaven</td>
      <td>2016-03-26 12:56:57</td>
      <td>36.43</td>
      <td>3015329826849</td>
      <td>30</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>529</th>
      <td>Fosterside</td>
      <td>2016-08-12 11:52:41</td>
      <td>28.08</td>
      <td>133077693483</td>
      <td>69</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>553</th>
      <td>West Alexis</td>
      <td>2016-01-16 00:33:02</td>
      <td>26.62</td>
      <td>1574788996743</td>
      <td>47</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>573</th>
      <td>Carrollfort</td>
      <td>2016-06-24 20:11:11</td>
      <td>6.45</td>
      <td>1092683495142</td>
      <td>55</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>602</th>
      <td>New David</td>
      <td>2016-01-12 20:48:43</td>
      <td>38.68</td>
      <td>5229089333754</td>
      <td>31</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>630</th>
      <td>Williamshire</td>
      <td>2016-06-22 07:53:44</td>
      <td>39.81</td>
      <td>5322918326146</td>
      <td>70</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>661</th>
      <td>Torresshire</td>
      <td>2016-10-29 12:28:18</td>
      <td>23.50</td>
      <td>6168304478087</td>
      <td>70</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>687</th>
      <td>New Aaron</td>
      <td>2016-08-12 17:14:50</td>
      <td>34.63</td>
      <td>6249037081192</td>
      <td>60</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>709</th>
      <td>Kelseyland</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>737</th>
      <td>Lake Sarashire</td>
      <td>2016-07-16 02:33:56</td>
      <td>34.69</td>
      <td>7536776262746</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2102</th>
      <td>West Evan</td>
      <td>2016-08-09 02:20:20</td>
      <td>39.26</td>
      <td>2350874801479</td>
      <td>4</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2114</th>
      <td>Sarahview</td>
      <td>2016-01-24 01:34:09</td>
      <td>21.42</td>
      <td>4350977208586</td>
      <td>18</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2129</th>
      <td>South Jennifer</td>
      <td>2016-10-05 12:22:37</td>
      <td>39.24</td>
      <td>1148273096494</td>
      <td>6</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2145</th>
      <td>Floresberg</td>
      <td>2016-07-03 11:24:38</td>
      <td>18.21</td>
      <td>4098574795183</td>
      <td>7</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2155</th>
      <td>Williamchester</td>
      <td>2016-08-28 17:40:49</td>
      <td>30.72</td>
      <td>8203822920323</td>
      <td>26</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2166</th>
      <td>Martinmouth</td>
      <td>2016-10-01 16:59:07</td>
      <td>15.78</td>
      <td>7253951228785</td>
      <td>5</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2175</th>
      <td>Port Guytown</td>
      <td>2016-05-23 23:19:25</td>
      <td>23.37</td>
      <td>2895832299221</td>
      <td>26</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2190</th>
      <td>New Cindyborough</td>
      <td>2016-09-25 16:34:43</td>
      <td>35.80</td>
      <td>3880166548267</td>
      <td>20</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2203</th>
      <td>New Michelleberg</td>
      <td>2016-11-17 19:04:51</td>
      <td>27.33</td>
      <td>4786622689927</td>
      <td>9</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2214</th>
      <td>North Tracyfort</td>
      <td>2016-05-07 11:43:48</td>
      <td>19.69</td>
      <td>4573622856127</td>
      <td>18</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2224</th>
      <td>Tiffanyton</td>
      <td>2016-03-18 22:23:02</td>
      <td>27.56</td>
      <td>9111212410554</td>
      <td>21</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2237</th>
      <td>East Cherylfurt</td>
      <td>2016-08-02 14:26:36</td>
      <td>36.94</td>
      <td>6776337445619</td>
      <td>9</td>
      <td>Suburban</td>
    </tr>
    <tr>
      <th>2250</th>
      <td>Horneland</td>
      <td>2016-07-19 10:07:33</td>
      <td>12.63</td>
      <td>8214498891817</td>
      <td>8</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2254</th>
      <td>Kinghaven</td>
      <td>2016-05-18 23:28:12</td>
      <td>20.53</td>
      <td>6432117120069</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2260</th>
      <td>New Johnbury</td>
      <td>2016-04-21 08:30:25</td>
      <td>56.60</td>
      <td>9002881309143</td>
      <td>6</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2264</th>
      <td>South Joseph</td>
      <td>2016-02-17 01:41:29</td>
      <td>57.52</td>
      <td>7365786843443</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2276</th>
      <td>Kennethburgh</td>
      <td>2016-10-19 13:13:17</td>
      <td>24.43</td>
      <td>2728236352387</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2286</th>
      <td>East Stephen</td>
      <td>2016-02-16 11:58:06</td>
      <td>22.43</td>
      <td>8118042484039</td>
      <td>6</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2296</th>
      <td>Stevensport</td>
      <td>2016-02-14 15:52:14</td>
      <td>22.20</td>
      <td>341262393081</td>
      <td>6</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2301</th>
      <td>West Kevintown</td>
      <td>2016-11-27 20:12:58</td>
      <td>12.92</td>
      <td>6460741616450</td>
      <td>5</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2308</th>
      <td>East Troybury</td>
      <td>2016-02-21 06:07:18</td>
      <td>45.12</td>
      <td>1607319707836</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2315</th>
      <td>Erikport</td>
      <td>2016-01-01 18:05:56</td>
      <td>11.76</td>
      <td>3568184448232</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2323</th>
      <td>Hernandezshire</td>
      <td>2016-02-20 08:17:32</td>
      <td>58.95</td>
      <td>3176534714830</td>
      <td>10</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2332</th>
      <td>Jacksonfort</td>
      <td>2016-10-09 02:18:33</td>
      <td>10.33</td>
      <td>1819118738960</td>
      <td>6</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2338</th>
      <td>East Leslie</td>
      <td>2016-04-21 18:44:59</td>
      <td>19.26</td>
      <td>5836114186294</td>
      <td>9</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2349</th>
      <td>North Whitney</td>
      <td>2016-04-01 21:21:37</td>
      <td>51.01</td>
      <td>612689673941</td>
      <td>10</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2359</th>
      <td>Manuelchester</td>
      <td>2016-03-21 22:15:25</td>
      <td>49.62</td>
      <td>6045427401799</td>
      <td>7</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2360</th>
      <td>Shelbyhaven</td>
      <td>2016-05-24 15:29:59</td>
      <td>18.11</td>
      <td>1144791937271</td>
      <td>9</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2366</th>
      <td>South Elizabethmouth</td>
      <td>2016-04-03 11:13:07</td>
      <td>22.79</td>
      <td>8193837300497</td>
      <td>3</td>
      <td>Rural</td>
    </tr>
    <tr>
      <th>2371</th>
      <td>Matthewside</td>
      <td>2016-02-23 17:46:29</td>
      <td>59.65</td>
      <td>241191157535</td>
      <td>4</td>
      <td>Rural</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 6 columns</p>
</div>




```python
av_fares = pyber_df_city["fare"].mean()
number_of_rides = pyber_df_city["city"].count()
drivers_count = pyber_df_city["driver_count"].last()
city_type = pyber_df_city["type"].last()

data_df = pd.DataFrame({"average fares": av_fares,
                        "number of rides": number_of_rides,
                        "number of drivers": drivers_count,
                        "city type": city_type
                        })
data_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>average fares</th>
      <th>city type</th>
      <th>number of drivers</th>
      <th>number of rides</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <td>23.928710</td>
      <td>Urban</td>
      <td>21</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <td>20.609615</td>
      <td>Urban</td>
      <td>67</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <td>37.315556</td>
      <td>Suburban</td>
      <td>16</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <td>23.625000</td>
      <td>Urban</td>
      <td>21</td>
      <td>22</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <td>21.981579</td>
      <td>Urban</td>
      <td>49</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Arnoldview</th>
      <td>25.106452</td>
      <td>Urban</td>
      <td>41</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Campbellport</th>
      <td>33.711333</td>
      <td>Suburban</td>
      <td>26</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Carrollbury</th>
      <td>36.606000</td>
      <td>Suburban</td>
      <td>4</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Carrollfort</th>
      <td>25.395517</td>
      <td>Urban</td>
      <td>55</td>
      <td>29</td>
    </tr>
    <tr>
      <th>Clarkstad</th>
      <td>31.051667</td>
      <td>Suburban</td>
      <td>21</td>
      <td>12</td>
    </tr>
    <tr>
      <th>Conwaymouth</th>
      <td>34.591818</td>
      <td>Suburban</td>
      <td>18</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Davidtown</th>
      <td>22.978095</td>
      <td>Urban</td>
      <td>73</td>
      <td>21</td>
    </tr>
    <tr>
      <th>Davistown</th>
      <td>21.497200</td>
      <td>Urban</td>
      <td>25</td>
      <td>25</td>
    </tr>
    <tr>
      <th>East Cherylfurt</th>
      <td>31.416154</td>
      <td>Suburban</td>
      <td>9</td>
      <td>13</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <td>26.169091</td>
      <td>Urban</td>
      <td>12</td>
      <td>22</td>
    </tr>
    <tr>
      <th>East Erin</th>
      <td>24.478214</td>
      <td>Urban</td>
      <td>43</td>
      <td>28</td>
    </tr>
    <tr>
      <th>East Jenniferchester</th>
      <td>32.599474</td>
      <td>Suburban</td>
      <td>22</td>
      <td>19</td>
    </tr>
    <tr>
      <th>East Leslie</th>
      <td>33.660909</td>
      <td>Rural</td>
      <td>9</td>
      <td>11</td>
    </tr>
    <tr>
      <th>East Stephen</th>
      <td>39.053000</td>
      <td>Rural</td>
      <td>6</td>
      <td>10</td>
    </tr>
    <tr>
      <th>East Troybury</th>
      <td>33.244286</td>
      <td>Rural</td>
      <td>3</td>
      <td>7</td>
    </tr>
    <tr>
      <th>Edwardsbury</th>
      <td>26.876667</td>
      <td>Urban</td>
      <td>11</td>
      <td>27</td>
    </tr>
    <tr>
      <th>Erikport</th>
      <td>30.043750</td>
      <td>Rural</td>
      <td>3</td>
      <td>8</td>
    </tr>
    <tr>
      <th>Eriktown</th>
      <td>25.478947</td>
      <td>Urban</td>
      <td>15</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Floresberg</th>
      <td>32.310000</td>
      <td>Suburban</td>
      <td>7</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Fosterside</th>
      <td>23.034583</td>
      <td>Urban</td>
      <td>69</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Hernandezshire</th>
      <td>32.002222</td>
      <td>Rural</td>
      <td>10</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Horneland</th>
      <td>21.482500</td>
      <td>Rural</td>
      <td>8</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Jacksonfort</th>
      <td>32.006667</td>
      <td>Rural</td>
      <td>6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Jacobfort</th>
      <td>24.779355</td>
      <td>Urban</td>
      <td>52</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Jasonfort</th>
      <td>27.831667</td>
      <td>Suburban</td>
      <td>25</td>
      <td>12</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>South Roy</th>
      <td>26.031364</td>
      <td>Urban</td>
      <td>35</td>
      <td>22</td>
    </tr>
    <tr>
      <th>South Shannonborough</th>
      <td>26.516667</td>
      <td>Suburban</td>
      <td>9</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Spencertown</th>
      <td>23.681154</td>
      <td>Urban</td>
      <td>68</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Stevensport</th>
      <td>31.948000</td>
      <td>Rural</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Stewartview</th>
      <td>21.614000</td>
      <td>Urban</td>
      <td>49</td>
      <td>30</td>
    </tr>
    <tr>
      <th>Swansonbury</th>
      <td>27.464706</td>
      <td>Urban</td>
      <td>64</td>
      <td>34</td>
    </tr>
    <tr>
      <th>Thomastown</th>
      <td>30.308333</td>
      <td>Suburban</td>
      <td>1</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Tiffanyton</th>
      <td>28.510000</td>
      <td>Suburban</td>
      <td>21</td>
      <td>13</td>
    </tr>
    <tr>
      <th>Torresshire</th>
      <td>24.207308</td>
      <td>Urban</td>
      <td>70</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Travisville</th>
      <td>27.220870</td>
      <td>Urban</td>
      <td>37</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Vickimouth</th>
      <td>21.474667</td>
      <td>Urban</td>
      <td>13</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Webstertown</th>
      <td>29.721250</td>
      <td>Suburban</td>
      <td>26</td>
      <td>16</td>
    </tr>
    <tr>
      <th>West Alexis</th>
      <td>19.523000</td>
      <td>Urban</td>
      <td>47</td>
      <td>20</td>
    </tr>
    <tr>
      <th>West Brandy</th>
      <td>24.157667</td>
      <td>Urban</td>
      <td>12</td>
      <td>30</td>
    </tr>
    <tr>
      <th>West Brittanyton</th>
      <td>25.436250</td>
      <td>Urban</td>
      <td>9</td>
      <td>24</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <td>22.330345</td>
      <td>Urban</td>
      <td>34</td>
      <td>29</td>
    </tr>
    <tr>
      <th>West Evan</th>
      <td>27.013333</td>
      <td>Suburban</td>
      <td>4</td>
      <td>12</td>
    </tr>
    <tr>
      <th>West Jefferyfurt</th>
      <td>21.072857</td>
      <td>Urban</td>
      <td>65</td>
      <td>21</td>
    </tr>
    <tr>
      <th>West Kevintown</th>
      <td>21.528571</td>
      <td>Rural</td>
      <td>5</td>
      <td>7</td>
    </tr>
    <tr>
      <th>West Oscar</th>
      <td>24.280000</td>
      <td>Urban</td>
      <td>11</td>
      <td>29</td>
    </tr>
    <tr>
      <th>West Pamelaborough</th>
      <td>33.799286</td>
      <td>Suburban</td>
      <td>27</td>
      <td>14</td>
    </tr>
    <tr>
      <th>West Paulport</th>
      <td>33.278235</td>
      <td>Suburban</td>
      <td>5</td>
      <td>17</td>
    </tr>
    <tr>
      <th>West Peter</th>
      <td>24.875484</td>
      <td>Urban</td>
      <td>61</td>
      <td>31</td>
    </tr>
    <tr>
      <th>West Sydneyhaven</th>
      <td>22.368333</td>
      <td>Urban</td>
      <td>70</td>
      <td>18</td>
    </tr>
    <tr>
      <th>West Tony</th>
      <td>29.609474</td>
      <td>Suburban</td>
      <td>17</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Williamchester</th>
      <td>34.278182</td>
      <td>Suburban</td>
      <td>26</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Williamshire</th>
      <td>26.990323</td>
      <td>Urban</td>
      <td>70</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Wiseborough</th>
      <td>22.676842</td>
      <td>Urban</td>
      <td>55</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Yolandafurt</th>
      <td>27.205500</td>
      <td>Urban</td>
      <td>7</td>
      <td>20</td>
    </tr>
    <tr>
      <th>Zimmermanmouth</th>
      <td>28.301667</td>
      <td>Urban</td>
      <td>45</td>
      <td>24</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 4 columns</p>
</div>




```python
urban_table=data_df.loc[data_df['city type']=='Urban']
suburban_table=data_df.loc[data_df['city type']=='Suburban']
rural_table=data_df.loc[data_df['city type']=='Rural']


urban_plt = plt.scatter(urban_table['number of rides'],urban_table['average fares'],marker="o", facecolors="lightcoral", edgecolors="black",
           s=urban_table['number of drivers']*5,label='Urban', alpha=0.75, linewidths=1.1)
suburban_plt = plt.scatter(suburban_table['number of rides'],suburban_table['average fares'],marker="o", facecolors="lightskyblue", edgecolors="black",
           s=suburban_table['number of drivers']*5,label='Suburban', alpha=0.75, linewidths=1.1)
rural_plt = plt.scatter(rural_table['number of rides'],rural_table['average fares'],marker="o", facecolors="gold", edgecolors="black",
           s=rural_table['number of drivers']*5,label='Rural', alpha=0.8, linewidths=1.1)


lgn=plt.legend(title='city types', loc="best")
lgn.legendHandles[0]._sizes=[50]
lgn.legendHandles[1]._sizes=[50]
lgn.legendHandles[2]._sizes=[50]
plt.title("pyber ride sharing data")
plt.xlabel("total number of rides per city")
plt.ylabel("average fare price")
plt.ylim(16,45)
plt.xlim(0, 37)
plt.show          
           

```




    <function matplotlib.pyplot.show>




![png](output_3_1.png)



```python
#percent of total fares by city type

urban_rides = urban_table['average fares'].sum()
sub_rides = suburban_table['average fares'].sum()
rural_rides = rural_table['average fares'].sum()

tot= urban_rides+sub_rides+rural_rides

urb_per_ride = urban_rides/tot
sub_per_ride = sub_rides/tot
rur_per_ride = rural_rides/tot

value = [urb_per_ride, sub_per_ride, rur_per_ride]
explode= (0.05, .05, .05)
color= ["lightcoral", "lightskyblue", "gold"]
labels= ["urban", "suburban", "rural"]
plt.title("percent of total fares by city")
plt.pie(value, labels=labels, explode=explode, colors=color,
       autopct="%1.1f%%", shadow=True, startangle=199)
plt.show()
```


![png](output_4_0.png)



```python
#percent of total rides by city type

urban_rides = urban_table['number of rides'].sum()
sub_rides = suburban_table['number of rides'].sum()
rural_rides = rural_table['number of rides'].sum()

tot= urban_rides+sub_rides+rural_rides

urb_per_ride = urban_rides/tot
sub_per_ride = sub_rides/tot
rur_per_ride = rural_rides/tot

value = [urb_per_ride, sub_per_ride, rur_per_ride]
explode= (0.05, 0.05, 0.05)
color= ["lightcoral", "lightskyblue", "gold"]
labels= ["urban", "suburban", "rural"]
plt.title("percent of total rides by city type")
plt.pie(value, labels=labels, explode=explode, colors=color,
       autopct="%1.1f%%", shadow=True, startangle=199)
plt.show()
```


![png](output_5_0.png)



```python
#percent of total drivers by city type

urban_rides = urban_table['number of drivers'].sum()
sub_rides = suburban_table['number of drivers'].sum()
rural_rides = rural_table['number of drivers'].sum()

tot= urban_rides+sub_rides+rural_rides

urb_per_ride = urban_rides/tot
sub_per_ride = sub_rides/tot
rur_per_ride = rural_rides/tot

value = [urb_per_ride, sub_per_ride, rur_per_ride]
explode= (0.05, 0.05, 0.05)
color= ["lightcoral", "lightskyblue", "gold"]
labels= ["urban", "suburban", "rural"]
plt.title("percent of total drivers by city type")
plt.pie(value, labels=labels, explode=explode, colors=color,
       autopct="%1.1f%%", shadow=True, startangle=199)
plt.show()
```


![png](output_6_0.png)

